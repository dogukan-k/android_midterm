package dku.midterim.com.dogukan_755495;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    Spinner spinner;
    TextView dailyRent;
    TextView days;
    SeekBar seekBar;
    RadioButton lessThan20;
    RadioButton between;
    RadioButton above;
    CheckBox gps;
    CheckBox childSeat;
    CheckBox unlimitedMilage;
    TextView amount;
    TextView totalPayment;
    Button btnViewDetail;

    int selectedCar = 0;
    int driverAgePaymentDifference = 0;
    int extraFeatures = 0;


    final List<Car> list = Car.getCarList();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinner = (Spinner) findViewById(R.id.spinner);
        dailyRent = findViewById(R.id.daily_rent);
        days = findViewById(R.id.days);
        seekBar = findViewById(R.id.seek_bar_days);
        lessThan20 = findViewById(R.id.less_than_20);
        between = findViewById(R.id.between_21_40);
        above = findViewById(R.id.above_60);
        gps = findViewById(R.id.c_box_gps);
        childSeat = findViewById(R.id.c_box_child);
        unlimitedMilage = findViewById(R.id.c_box_milage);
        totalPayment = findViewById(R.id.lbl_total_payment);
        amount = findViewById(R.id.lbl_amount);
        btnViewDetail = findViewById(R.id.btn_detail);


        //Spinner
        //Call cars and put it in a spinner

        ArrayAdapter adapter = new ArrayAdapter<>(this, R.layout.support_simple_spinner_dropdown_item, list);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                seekBar.setProgress(0);
                selectedCar = position;
                dailyRent.setText("Daily Rent " + list.get(position).getPrice() + " Cad");

                //To eleminate please choose a car header
                if (position != 0) {

                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        //SeekBar

        seekBar.setProgress(0);
        seekBar.incrementProgressBy(1);
        seekBar.setMax(10);

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {

                days.setText(String.valueOf(i) + " Days");

                //Total amount and amount methods...
                if (selectedCar != 0) {
                    amountInCad();
                    totalPayment();
                }


            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        lessThan20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (selectedCar != 0) {
                    driverAgePaymentDifference = 5;

                    amountInCad();
                    totalPayment();
                }


            }
        });

        between.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (selectedCar != 0) {

                    driverAgePaymentDifference = 0;
                    amountInCad();
                    totalPayment();
                }


            }
        });

        above.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (selectedCar != 0) {

                    driverAgePaymentDifference = -10;
                    amountInCad();
                    totalPayment();
                }


            }
        });

        gps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (selectedCar != 0) {

                    if (gps.isChecked()) {
                        extraFeatures += 5;
                    } else {
                        extraFeatures -= 5;
                    }


                    amountInCad();
                    totalPayment();
                }

            }
        });

        childSeat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (selectedCar != 0) {

                    if (childSeat.isChecked()) {
                        extraFeatures += 7;
                    } else {
                        extraFeatures -= 7;
                    }


                    amountInCad();
                    totalPayment();
                }

            }
        });

        unlimitedMilage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (selectedCar != 0) {

                    if (unlimitedMilage.isChecked()) {
                        extraFeatures += 10;
                    } else {
                        extraFeatures -= 10;
                    }


                    amountInCad();
                    totalPayment();
                }

            }
        });


    }

    public double amountInCad() {

        double amount = (list.get(selectedCar).getPrice() * seekBar.getProgress()) + (driverAgePaymentDifference * seekBar.getProgress()) + (extraFeatures * seekBar.getProgress());

        this.amount.setText(String.format("%.2f", amount));

        return amount;
    }

    public double totalPayment() {

        double totalPayment = (amountInCad() * 113) / 100;

        this.totalPayment.setText(String.format("%.2f", totalPayment));

        return totalPayment;
    }

    public void viewDetail(View v) {

        if(selectedCar != 0 && (lessThan20.isChecked() || between.isChecked() || above.isChecked()) && seekBar.getProgress() != 0 ){


            String features = "";
            String name = list.get(selectedCar).getCarName();
            String amount = (String) this.amount.getText();
            String total = (String) this.totalPayment.getText();


            if (gps.isChecked()) {
                features += "Gps| ";
            }
            if (childSeat.isChecked()) {
                features += "Child Seat| ";
            }
            if (unlimitedMilage.isChecked()) {
                features += "Unlimited Milage|";
            }

            Intent i = new Intent(this, DetailActivity.class);
            i.putExtra("name", name);
            i.putExtra("features", features);
            i.putExtra("amount", amount);
            i.putExtra("totalAmount", total);
            i.putExtra("days", seekBar.getProgress());

            startActivity(i);

        }

        else {
            Toast.makeText(MainActivity.this, "Check the fields.", Toast.LENGTH_SHORT).show();
        }




    }
}