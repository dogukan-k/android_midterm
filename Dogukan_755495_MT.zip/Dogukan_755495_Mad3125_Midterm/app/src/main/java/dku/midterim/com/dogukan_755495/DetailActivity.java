package dku.midterim.com.dogukan_755495;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class DetailActivity extends AppCompatActivity {


    TextView carBrand ;
    TextView options ;
    TextView detail ;

    String carName = "";
    String addedOPtions = "";
    String detailOfRental = "" ;
    String amount = "" ;
    String totalAmount = "" ;
    int numOfDay = 0 ;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        carBrand = findViewById(R.id.brand_of_the_car);
        options = findViewById(R.id.options);
        detail = findViewById(R.id.detail);


        carName = getIntent().getExtras().getString("name");
        addedOPtions = getIntent().getExtras().getString("features");
        amount = getIntent().getExtras().getString("amount");
        totalAmount = getIntent().getExtras().getString("totalAmount");
        numOfDay = getIntent().getExtras().getInt("days") ;

        carBrand.setText(carName);

        if(addedOPtions.equals("")){
            options.setText("No extra options added");
        }

        else {
            options.setText(addedOPtions+" applied");
        }


        detailOfRental =    "The car is detailed above is rented for "+numOfDay +" day/s \n" +
                        "Amount is " + amount + " Canadian Dollar\n" +
                "Total Amount is " + totalAmount + "Canadian Dollar";

        detail.setText(detailOfRental);


    }
}
