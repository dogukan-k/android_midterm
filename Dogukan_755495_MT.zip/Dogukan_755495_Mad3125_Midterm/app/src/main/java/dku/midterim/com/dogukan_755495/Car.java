package dku.midterim.com.dogukan_755495;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Car implements Serializable {

    private String carName ;
    private double price ;


    public String getCarName() {
        return carName;
    }

    public void setCarName(String carName) {
        this.carName = carName;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public Car(){

    }

    public Car (String carName , double price){
        this.carName = carName ;
        this.price = price ;
    }


    @Override
    public String toString() {
        return carName ;
    }

    public static List<Car> getCarList(){

        Car chooseCar = new Car("Please choose a car" , 0);
        Car bmw = new Car("BMW", 25);
        Car audi = new Car("Audi", 27);
        Car cadillac = new Car("Cadillac", 22);
        Car wolkswagen = new Car("Wolkswagen", 18);
        Car mercedes = new Car("Mercedes", 30);
        Car peugeot = new Car("Peugeot", 20);
        Car dodge = new Car("Dodge" , 21);

        List<Car> cars = new ArrayList<>() ;
        cars.add(chooseCar);
        cars.add(bmw);
        cars.add(audi);
        cars.add(cadillac);
        cars.add(wolkswagen);
        cars.add(mercedes);
        cars.add(peugeot);
        cars.add(dodge);


        return cars ;
    }


}
